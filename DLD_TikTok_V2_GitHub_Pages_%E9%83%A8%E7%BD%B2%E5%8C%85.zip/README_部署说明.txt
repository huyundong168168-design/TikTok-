DLD BAZAR TikTok V2 部署说明

上传 tiktok-v2/index.html 到已发布 GitHub Pages 的仓库根目录下 tiktok-v2/index.html。
请勿替换仓库根目录的 index.html，以免影响其他工具。
部署后访问 https://huyundong168168-design.github.io/tiktok-v2/ （实际链接取决于 Pages 仓库设置）。
只有已允许的 GitHub Pages Origin 才能直接读取 https://dldbazar.com/api/products。
本工具仅GET只读，不会修改商城数据，TikTok 上传须人工确认。
